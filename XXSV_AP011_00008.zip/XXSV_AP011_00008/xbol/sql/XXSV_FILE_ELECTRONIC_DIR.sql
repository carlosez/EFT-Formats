--select * from all_directories

create or replace directory
XX_BANK_ELECTRONIC_DIR AS '/interface/i_mili/PMILII/outgoing/ALL/BANK';

/
exit
/