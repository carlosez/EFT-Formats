create OR REPLACE public synonym XX_AP_EFT_FORMATS for bolinf.XX_AP_EFT_FORMATS;

create OR REPLACE public synonym XX_AP_EFT_FORMAT_DEFINITIONS for bolinf.XX_AP_EFT_FORMAT_DEFINITIONS;

create OR REPLACE public synonym XX_AP_EFT_FORMATS_PKG for bolinf.XX_AP_EFT_FORMATS_PKG;

create OR REPLACE public synonym XX_AP_EFT_FORMATS_UTL for bolinf.XX_AP_EFT_FORMATS_UTL;
/
exit
/