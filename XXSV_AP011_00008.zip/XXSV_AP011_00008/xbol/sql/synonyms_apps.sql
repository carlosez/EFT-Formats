create OR REPLACE public synonym XX_AP_EFT_FORMATS for bolinf.XX_AP_EFT_FORMATS;

create OR REPLACE public synonym XX_AP_EFT_FORMAT_DEFINITIONS for bolinf.XX_AP_EFT_FORMAT_DEFINITIONS;

create OR REPLACE public synonym XX_AP_EFT_FORMATS_S for bolinf.XX_AP_EFT_FORMATS_S;

create OR REPLACE public synonym XX_AP_EFT_FORMAT_DEFINITIONS_S for bolinf.XX_AP_EFT_FORMAT_DEFINITIONS_S;
/
exit
/