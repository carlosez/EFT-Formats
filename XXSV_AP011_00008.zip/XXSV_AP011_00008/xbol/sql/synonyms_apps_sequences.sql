create OR REPLACE public synonym XX_AP_EFT_FORMATS_S for bolinf.XX_AP_EFT_FORMATS_S;
create OR REPLACE public synonym XX_AP_EFT_FORMAT_DEFINITIONS_S for bolinf.XX_AP_EFT_FORMAT_DEFINITIONS_S;
exit