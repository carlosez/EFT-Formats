create public synonym XX_AP_EFT_FORMATS for bolinf.XX_AP_EFT_FORMATS;

create public synonym XX_AP_EFT_FORMAT_DEFINITIONS for bolinf.XX_AP_EFT_FORMAT_DEFINITIONS;
/
exit
/